
# BEFORE YOU START


**** ALL THESE SCRIPTS ARE CREATED BY THIRD PARTIES ****
     **** THEY ARE AS IS, USE AT YOUR OWN RISK! ****

# ADDITIONS

In this directory you will find additional scripts that are build by others.

## change_password.tgz

by George Vieira <george at citadelcomputer dot com dot au>
SquirrelMail plugin to change your passwor

## cleanupdirs.pl

by jared bell <jared at beol dot net>
Displays a list of mailboxes that need to be deleted

## mailbox_remover.pl

by Petr Znojemsky
Deletes all unused mailboxes

## mkeveryone.pl

by Joshua Preston
Generate an 'everybody' alias for a domain.

## pfa_maildir_cleanup.pl
by Stephen Fulton <sfulton at esoteric dot ca>
Deletes all unused mailboxes

## postfixadmin-0.3-1.4.tar.gz

by Florian Kimmerl <info at spacekoeln dot de>

The Postfixadmin SquirrelMail plugin let users change their virtual alias,
vacation status/message and password.

See also :  https://github.com/postfixadmin/postfixadmin/tree/master/ADDITIONS/squirrelmail-plugin


##  virtualmaildel.php

by George Vieira <george at citadelcomputer dot com dot au>
Deletes all unused mailboxes

## Example mailbox / domain scripts for Postfixadmin

- postfixadmin-mailbox-postcreation.sh
- postfixadmin-mailbox-postdeletion.sh
- postfixadmin-domain-postdeletion.sh
by Troels Arvin <troels@arvin.dk>

Examples of scripts relevant to the optional 


$CONF['mailbox_postcreation_script'],
$CONF['mailbox_postdeletion_script'] and
$CONF['domain_postdeletion_script']  configuration options.


## Cyrus Quota Usage

See https://github.com/o-m-d/cyrus-quotausage-to-pfa

