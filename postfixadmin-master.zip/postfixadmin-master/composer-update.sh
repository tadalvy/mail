#!/bin/bash

# for github :
composer update --no-dev

# for local testing/dev:
# composer update
